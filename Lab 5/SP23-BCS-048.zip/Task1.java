class Address{
    private int houseNo;
    private int streetNo;
    private String city;
    private String code;
    Address(){
        streetNo=0;
        houseNo=0;
        city="";
        code="";
    }
    Address(int streetNo,int houseNo,String city,String code){
        this.streetNo=streetNo;
        this.houseNo=houseNo;
        this.city=city;
        this.code=code;
    }
    public int getStreetNo() {
        return streetNo;
    }
    public int getHouseNo() {
        return houseNo;
    }
    public String getCity() {
        return city;
    }
    public String getCode() {
        return code;
    }
    public void setStreetNo(int streetNo) {
        this.streetNo = streetNo;
    }
    public void setHouseNo(int houseNo) {
        this.houseNo = houseNo;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public void setCode(String code) {
        this.code = code;
    }
    public void displayAddress(){
        System.out.println("House Number : "+houseNo);
        System.out.println("Street Number : "+streetNo);
        System.out.println("City : "+city);
        System.out.println("Zip Code : "+code);
    }
}
class Person{
    private String name;
    private Address address;
    Person(){
        name="";
        address=new Address();
    }
    Person(String name,Address address){
        this.name=name;
        this.address=address;
    }
    public String getName() {
        return name;
    }
    public Address getAddress() {
        return address;
    }
    public void setName(String name) {
        this.name = name;
    }
    public void setAddress(Address address) {
        this.address = address;
    }
    public void displayPerson(){
        System.out.println("Person Name : "+name);
        System.out.println("Person Address ... ");
        address.displayAddress();
    }
}

public class Task1 {
    public static void main(String[] args) {
        Address adr = new Address(12, 2, "lahore", "65500");
        Person auth = new Person("Mathar", adr);
        auth.displayPerson();
    }
}
