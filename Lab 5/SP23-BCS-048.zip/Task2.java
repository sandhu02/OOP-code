class Book{
    private Person author;
    private String bookName;
    private String publisher;
    Book(){
        author=new Person();
        bookName="";
        publisher="";
    }
    Book(Person author,String bookName,String publisher){
        this.author=author;
        this.bookName=bookName;
        this.publisher=publisher;
    }
    public Person getAuthor() {
        return author;
    }
    public String getBookName() {
        return bookName;
    }
    public String getPublisher() {
        return publisher;
    }
    public void setAuthor(Person author) {
        this.author = author;
    }
    public void setBookName(String bookName) {
        this.bookName = bookName;
    }
    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }
    public void displayBook(){
        System.out.println("Author Name : "+author.getName());
        System.out.println("Book Name : "+bookName);
        System.out.println("Publisher : "+publisher);
    }
}

public class Task2 {
    public static void main(String[] args) {
        Address adr = new Address(12, 2, "lahore", "65500");
        Person auth = new Person("Mathar", adr);

        String bookName="a new Dawn";
        String publisher="Sincity Publishers";
        Book b= new Book(auth,bookName,publisher);
        b.displayBook();
    }
}
