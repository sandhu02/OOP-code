class Point{
    private double x_cord;
    private double y_cord;
    Point(){
        x_cord=0;
        y_cord=0;
    }
    Point(double x_cord,double y_cord){
        this.x_cord=x_cord;
        this.y_cord=y_cord;
    }
    public double getX_cord() {
        return x_cord;
    }
    public double getY_cord() {
        return y_cord;
    }
    public void setX_cord(double x_cord) {
        this.x_cord = x_cord;
    }
    public void setY_cord(double y_cord) {
        this.y_cord = y_cord;
    }
    public void displayPoint(){
        System.out.println("x-coordinate : "+x_cord);
        System.out.println("y-coordiante : "+y_cord);
    }
}

class Line{
    private Point p1;
    private Point p2;
    public Line(){
        p1=new Point();
        p2=new Point();
    }
    public Line(Point p1,Point p2){
        this.p1=p1;
        this.p2=p2;
    }
    public Point getP1() {
        return p1;
    }
    public Point getP2() {
        return p2;
    }
    public void setP1(Point p1) {
        this.p1 = p1;
    }
    public void setP2(Point p2) {
        this.p2 = p2;
    }
    public double lineLength(){
        double x1 = p1.getX_cord();
        double x2 = p2.getX_cord();
        double y1 = p1.getY_cord();
        double y2 = p2.getY_cord();
        double length=Math.sqrt((x2-x1)*(x2-x1) + (y2-y1)*(y2-y1));
        return length;        
    }
}
public class Task3 {
    public static void main(String[] args) {
        Point p1 = new Point(12.00,5.00);
        Point p2 = new Point(15.00,15.00);
        Line l1 = new Line(p1, p2);
        System.out.println(l1.lineLength());
    }
}
